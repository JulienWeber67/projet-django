from django.shortcuts import render

# Create your views here.


def index(request):
    return render(request, 'mesgab/index.html')

def formulair(request):
    nom=request.GET["nom"]
    return render(request,'mesjeux/repformulaire.html',{"nom":nom})