from django.db import models

# Create your models here.

class GenreJeux(models.Model):
    nomgenre = models.CharField(max_length = 100)

    def __str__(self):
        chaine = f"{self.nomgenre}"
        return chaine

class ajoutJeux(models.Model):
    nomjeu = models.CharField(max_length = 100)
    prix = models.CharField(max_length =100)
    classification = models.CharField(max_length = 100)
    resumejeu = models.TextField(null = True, blank = True)
    nomgenre = models.ForeignKey(GenreJeux, on_delete=models.CASCADE, null=True)
    def __str__(self):
        chaine = f"{self.nomjeu} {self.prix} {self.classification} {self.resumejeu} "
        return chaine

#class jeuxvideo(models.Model):
#    jeuxnom = models.CharField(max_length = 100)
#    fonctionalite = models.CharField(max_length =100)
#    genre = models.CharField(max_length = 100)
#    caracteristique = models.TextField(null = True, blank = True)
#    def __str__(self):
#        chaine = f"{self.jeuxnom} {self.fonctionalite} {self.genre} {self.caracteristique} "
#       return chaine