from django.apps import AppConfig


class MesjeuxConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mesjeux'
