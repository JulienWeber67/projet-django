from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models

class GenreJeuxForm(ModelForm):
    class Meta:
     model = models.GenreJeux
     fields = ('nomgenre',)
     labels = {
      'nomgenre' : _('Inserez un genre'),
}


class ajoutJeuxForm(ModelForm):
 class Meta:
  model = models.ajoutJeux
  fields = ('nomjeu', 'prix', 'classification', 'resumejeu', 'nomgenre')
  labels = {
   'nomjeu': _('nom'),
   'prix': _('prix'),
   'classification': _('classification'),
   'resumejeu': _('Résumé'),
   'nomgenre': _('Choisissez le genre'),
  }

#class jeuxvideo(ModelForm):
# class Meta:
#  models = models.jeuxvideo
#  fields = ('jeuxnom','genre','fonctionalite','caracteristique')
#  labels = {
#   'jeuxnom': _('jeuxnom'),
#   'genre': _('genre'),
#   'fonctionalite': _('fonctionalite'),
#   'caracteristique': _('caracteristique')
#  }