from django.http import HttpResponseRedirect
from django.shortcuts import render
from .forms import GenreJeuxForm, ajoutJeuxForm
from .import models

# Create your views here.


def index(request):
    toutgenre = models.GenreJeux.objects.all()
    toutjeu = models.ajoutJeux.objects.all()
    return render(request, 'jeux/index.html',{"toutgenre": toutgenre,"toutjeu" : toutjeu})

def ajoutgenre(request): #affichage du formulaire
    form = GenreJeuxForm()
    return render(request,"jeux/ajoutgenrejeux.html",{"form" : form})

def traitementgenre(request): # traitement du formulaire
    gform = GenreJeuxForm(request.POST)
    if gform.is_valid():
        genrejeux = gform.save()
        return HttpResponseRedirect("/mesjeux/index/")
#        return render(request,"jeux/affichegenrejeux.html",{"genrejeux": genrejeux})
    else:
        return render(request,"jeux/ajoutgenrejeux.html",{"form": gform})

def affichegenre(request,id):
    genrejeux = models.GenreJeux.objects.get(pk=id)
    return render(request,'jeux/affichegenrejeux.html',{"genrejeux": genrejeux})

def deletegenre(request,id):
    genrejeux = models.GenreJeux.objects.get(pk=id)
    genrejeux.delete()
    return HttpResponseRedirect("/mesjeux/index/")

def updategenre(request,id):
    genrejeux = models.GenreJeux.objects.get(pk=id)
    genrejeux.delete()
    return HttpResponseRedirect("/mesjeux/ajoutgenre/")

#------------------------- Deuxième CRUD

def ajoutjeu(request): #affichage du formulaire
    form = ajoutJeuxForm()
    return render(request,"jeux/ajoutdejeux.html",{"form" : form})

def traitementjeu(request): # traitement du formulaire
    gform = ajoutJeuxForm(request.POST)
    if gform.is_valid():
        nouvjeux = gform.save()
        return HttpResponseRedirect("/mesjeux/index/")
#        return render(request,"jeux/affichegenrejeux.html",{"genrejeux": genrejeux})
    else:
        return render(request,"jeux/ajoutdejeux.html",{"form": gform})

def affichejeu(request,id):
    nouvjeux = models.ajoutJeux.objects.get(pk=id)
    return render(request,'jeux/affichejeux.html',{"nouvjeux": nouvjeux})

def deletejeu(request,id):
    nouvjeux = models.ajoutJeux.objects.get(pk=id)
    nouvjeux.delete()
    return HttpResponseRedirect("/mesjeux/index/")

def updatejeu(request,id):
    nouvjeux = models.ajoutJeux.objects.get(pk=id)
    nouvjeux.delete()
    return HttpResponseRedirect("/mesjeux/ajoutjeu/")

# def traitementupdate(request,id):
#    form = form.GenreJeux(request.POST)
 #   if form.is_valid ():
  #      genrejeux = form.save(commit = False)


#------------------------- Ancienne version
"""def formulaire(request):
    nom=request.GET["nom"]
    return render(request,'mesgab/formulaire.html',{"nom":nom})

def repformulaire(request):
    return render(request, 'mesgab/repformulaire.html')

def squelettejeux(request):
    return render(request, 'mesgab/squelettejeux.html')

def squelette(request):
    return render(request, 'static/squelette.css')

def ajout(request):
    if request.method == "POST":
        form = jeuxgenre(request)
        if form.is_valid():
            genrejeux = form.save()
            return render(request,"/mesgab/categorie.html",{"genrejeux" : genrejeux})
        else:
            return render(request,"mesgab/ajout.html",{"form": form})
    else:
        form = jeuxgenre()
        return render(request,"/mesgab/ajout.html",{"form": form})

def traitement(request):
    return render(request, 'mesgab/traitement.html')

def categorie(request):
    return render(request, 'mesgab/categorie.html')

def jeux(request):
    return  render(request, 'mesgab/jeux.html')"""