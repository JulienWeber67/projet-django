from django.urls import path
from . import views
urlpatterns = [
    path('', views.index),
    path('index/', views.index),

    path("ajoutgenre/", views.ajoutgenre),
    path("traitementgenre/", views.traitementgenre),
    path("affichegenre/<int:id>/", views.affichegenre),
    path("deletegenre/<int:id>/", views.deletegenre),
    path("updategenre/<int:id>/", views.updategenre),

    # ---------------------- ancienne version
    # path('formulaire/', views.formulaire),
    # path('repformulaire/', views.repformulaire),
    # path('squelettejeux/',views.squelettejeux),
    # path('squelette/',views.squelette),
    # path('ajout/',views.ajout),
    # path('categorie/',views.categorie),
    # path('jeux/',views.jeux),
    # path('traitement/',views.traitement)
]
