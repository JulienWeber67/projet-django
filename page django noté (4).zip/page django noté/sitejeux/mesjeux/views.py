from django.http import HttpResponseRedirect
from django.shortcuts import render
from .forms import GenreJeuxForm
from .import models

# Create your views here.


def index(request):
    toutgenre = models.GenreJeux.objects.all()
    return render(request, 'jeux/index.html',{"toutgenre": toutgenre})

def ajoutgenre(request): #affichage du formulaire
    form = GenreJeuxForm()
    return render(request,"jeux/ajoutgenrejeux.html",{"form" : form})

def traitementgenre(request): # traitement du formulaire
    gform = GenreJeuxForm(request.POST)
    if gform.is_valid():
        genrejeux = gform.save()
        return HttpResponseRedirect("/mesjeux/index/")
#        return render(request,"jeux/affichegenrejeux.html",{"genrejeux": genrejeux})
    else:
        return render(request,"jeux/ajoutgenrejeux.html",{"form": gform})

def affichegenre(request,id):
    genrejeux = models.GenreJeux.objects.get(pk=id)
    return render(request,'jeux/affichegenrejeux.html',{"genrejeux": genrejeux})

def deletegenre(request,id):
    genrejeux = models.GenreJeux.objects.get(pk=id)
    genrejeux.delete()
    return HttpResponseRedirect("/mesjeux/index/")

def updategenre(request,id):
    genrejeux = models.GenreJeux.objects.get(pk=id)
    form = form.GenreJeux(())
    return HttpResponseRedirect("/mesjeux/index/")

def traitementupdate(request,id):
    form = form.GenreJeux(request.POST)
    if form.is_valid ():
        genrejeux = form.save(commit = False)


#------------------------- Ancienne version
"""def formulaire(request):
    nom=request.GET["nom"]
    return render(request,'mesgab/formulaire.html',{"nom":nom})

def repformulaire(request):
    return render(request, 'mesgab/repformulaire.html')

def squelettejeux(request):
    return render(request, 'mesgab/squelettejeux.html')

def squelette(request):
    return render(request, 'static/squelette.css')

def ajout(request):
    if request.method == "POST":
        form = jeuxgenre(request)
        if form.is_valid():
            genrejeux = form.save()
            return render(request,"/mesgab/categorie.html",{"genrejeux" : genrejeux})
        else:
            return render(request,"mesgab/ajout.html",{"form": form})
    else:
        form = jeuxgenre()
        return render(request,"/mesgab/ajout.html",{"form": form})

def traitement(request):
    return render(request, 'mesgab/traitement.html')

def categorie(request):
    return render(request, 'mesgab/categorie.html')

def jeux(request):
    return  render(request, 'mesgab/jeux.html')"""