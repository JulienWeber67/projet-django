from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models

class GenreJeuxForm(ModelForm):
    class Meta:
     model = models.GenreJeux
     fields = ('nom', 'detail', 'exemple', 'resume')
     labels = {
      'nom' : _('nom'),
      'detail' : _('detail') ,
      'exemple' : _('exemple de jeu'),
      'resume' : _('Résumé')
}

#class jeuxvideo(ModelForm):
# class Meta:
#  models = models.jeuxvideo
#  fields = ('jeuxnom','genre','fonctionalite','caracteristique')
#  labels = {
#   'jeuxnom': _('jeuxnom'),
#   'genre': _('genre'),
#   'fonctionalite': _('fonctionalite'),
#   'caracteristique': _('caracteristique')
#  }