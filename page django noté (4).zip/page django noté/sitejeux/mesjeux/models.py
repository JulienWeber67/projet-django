from django.db import models

# Create your models here.

class GenreJeux(models.Model):
    nom = models.CharField(max_length = 100)
    detail = models.CharField(max_length =100)
    exemple = models.CharField(max_length = 100)
    resume = models.TextField(null = True, blank = True)
    def __str__(self):
        chaine = f"{self.nom} {self.detail} {self.exemple} {self.resume} "
        return chaine

#class jeuxvideo(models.Model):
#    jeuxnom = models.CharField(max_length = 100)
#    fonctionalite = models.CharField(max_length =100)
#    genre = models.CharField(max_length = 100)
#    caracteristique = models.TextField(null = True, blank = True)
#    def __str__(self):
#        chaine = f"{self.jeuxnom} {self.fonctionalite} {self.genre} {self.caracteristique} "
#       return chaine