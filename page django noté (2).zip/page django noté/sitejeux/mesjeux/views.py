from django.shortcuts import render
from .forms import jeuxgenre
from .import models
# Create your views here.


def index(request):
    return render(request, 'mesgab/index.html')

def formulaire(request):
    nom=request.GET["nom"]
    return render(request,'mesjeux/formulaire.html',{"nom":nom})

def repformulaire(request):
    return render(request, 'mesjeux/repformulaire.html')

def squelettejeux(request):
    return render(request, 'mesgab/squelettejeux.html')

def squelette(request):
    return render(request, 'mesjeux/squelette.css')

def ajout(request):
    if request.method == "POST":
        form = jeuxgenre(request)
        if form.is_valid():
            genrejeux = form.save()
            return render(request,"/mesjeux/categorie.html",{"genrejeux" : genrejeux})
        else:
            return render(request,"mesjeux/ajout.html",{"form": form})
    else:
        form = jeuxgenre()
        return render(request,"/mesjeux/ajout.html",{"form": form})
