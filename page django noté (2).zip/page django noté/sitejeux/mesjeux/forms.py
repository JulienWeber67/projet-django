from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models
class jeuxgenre(ModelForm):
    class Meta:
     model = models.genrejeux
     fields = ('nom', 'detail', 'exemple','resume')
     labels = {
     'nom' : _('nom'),
     'detail' : _('detail') ,
     'exemple' : _('nombres␣de␣pages'),
     'resume' : _('Résumé')
}