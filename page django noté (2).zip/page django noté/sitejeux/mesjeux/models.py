from django.db import models

# Create your models here.

class genrejeux(models.Model):
    nom = models.CharField(max_length = 100)
    detail = models.CharField(max_length =100)
    exemple = models.CharField(max_length = 100)
    resume = models.TextField(null = True, blank = True)
    def __str__(self):
        chaine = f"{self.nom} {self.detail} {self.exemple} {self.resume} "