from django.urls import path
from . import views
urlpatterns = [
    path('index/', views.index),
    path('formulaire/', views.formulaire),
    path('repformulaire/', views.repformulaire),
    path('squelettejeux/',views.squelettejeux),
    path('squelette/',views.squelette),
    path('ajout/',views.ajout),
]
